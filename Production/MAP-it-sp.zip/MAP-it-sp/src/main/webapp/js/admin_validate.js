function validateLogin(){
    let admin_username = document.getElementById("username").value;
    let admin_pass = document.getElementById("password").value;

    if(!admin_pass || !admin_username)
    {
        window.alert("Please fill out every field in the Admin Login Form!");
        return false;
    }

    else{
        return true;
    }

}
