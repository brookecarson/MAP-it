package com.example.mapitsp.dao;
import com.example.mapitsp.model.contactSub;

import java.sql.*;

import static com.example.mapitsp.Utils.getConnection;

public class contactSubDAO {

    private static final String INSERT_CONTACT = "INSERT INTO contact_submissions" + " (name, message, date_time, number) VALUES " + "(?,?,?,?)";

    public void insertContactSub(contactSub submission){
        try(Connection connection = getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CONTACT)){
            preparedStatement.setString(1, submission.getName());
            preparedStatement.setString(2, submission.getMessage());
            preparedStatement.setString(3, submission.getDate_time());
            preparedStatement.setString(4, submission.getNumber());
        }catch (Exception e){
            System.err.println(e.getLocalizedMessage());
        }
    }
}
