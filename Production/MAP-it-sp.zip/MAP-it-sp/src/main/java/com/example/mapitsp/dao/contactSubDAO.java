package com.example.mapitsp.dao;
import com.example.mapitsp.model.contactSub;

import java.sql.*;

import static com.example.mapitsp.Utils.getConnection;

public class contactSubDAO {

    private static final String INSERT_CONTACT = "INSERT INTO contact_submissions" + " (contact_name, contact_message, contact_date, contact_number, contact_email) VALUES " + "(?,?,?,?,?);";

    public void insertContactSub(contactSub submission){
        try(Connection connection = getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CONTACT)){
            preparedStatement.setString(1, submission.getName());
            preparedStatement.setString(2, submission.getMessage());
            preparedStatement.setDate(3, submission.getDate());
            preparedStatement.setString(4, submission.getNumber());
            preparedStatement.setString(5, submission.getEmail());
            preparedStatement.executeUpdate();
        }catch (Exception e){
            System.err.println(e.getLocalizedMessage());
        }
    }
}
