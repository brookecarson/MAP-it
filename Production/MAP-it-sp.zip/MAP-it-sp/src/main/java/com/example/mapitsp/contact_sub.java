package com.example.mapitsp;

import java.sql.Timestamp;

public class contact_sub {

    private String name;
    private String email;
    private String message;
    private Timestamp date_time;
    private String number;

    public contact_sub(){

    }

    public contact_sub(String name, String email, String message, Timestamp date_time, String number) {
        this.name = name;
        this.email = email;
        this.message = message;
        this.date_time = date_time;
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Timestamp getDate_time() {
        return date_time;
    }

    public void setDate_time(Timestamp date_time) {
        this.date_time = date_time;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
