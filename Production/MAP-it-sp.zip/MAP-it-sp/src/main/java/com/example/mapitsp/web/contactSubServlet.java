package com.example.mapitsp.web;

import com.example.mapitsp.dao.contactSubDAO;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/contact-submission")
public class contactSubServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private contactSubDAO contactSubDAO;


    public void init() {
        contactSubDAO = new contactSubDAO();
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //String action = request.getServletPath();
        //try catch with swtich cases

        insertSubmission(request,response);
    }

    private void insertSubmission(HttpServletRequest request, HttpServletResponse response)
    {
        //
    }
}
