package com.example.mapitsp.dao;
import com.example.mapitsp.model.contactSub;

import java.sql.*;

import static com.example.mapitsp.Utils.getConnection;

public class contactSubDAO {

    private static final String INSERT_CONTACT = "INSERT INTO contact_submissions" + " (name, email, message, date_time, number) VALUES " + "(?,?,?,?,?);";

    public void insertContactSub(contactSub submission){
        try(Connection connection = getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CONTACT)){
            preparedStatement.setString(1, submission.getName());
            preparedStatement.setString(2, submission.getEmail());
            preparedStatement.setString(3, submission.getMessage());
            preparedStatement.setTimestamp(4, submission.getDate_time());
            preparedStatement.setString(5, submission.getNumber());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        }catch (Exception e){
            System.err.println(e.getLocalizedMessage());
        }
    }
}
