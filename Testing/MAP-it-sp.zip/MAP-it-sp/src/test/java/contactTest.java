import com.example.mapitsp.dao.contactSubDAO;
import com.example.mapitsp.model.contactSub;
import com.example.mapitsp.web.adminServlet;
import com.example.mapitsp.web.contactSubServlet;
import org.junit.jupiter.api.Test;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


class ContactTest {

    private static final String INSERT_CONTACT = "INSERT INTO contact_submissions" + " (name, email, message, date_time, number) VALUES " + "(?,?,?,?,?);";
    private static final String SELECT_SUB_BY_ID = "select contact_id,contact_name,contact_message,contact_date,contact_number,contact_email from contact_submissions where contact_id = ?;";
    private static final String SELECT_ALL_SUBS = "select * from contact_submissions";
    private static final String DELETE_SUB_SQL = "delete from contact_submissions where contact_id = ?;";
    private static final String UPDATE_SUB_SQL = "update contact_submissions set contact_name = ?, contact_message = ?, contact_date = ?, contact_number = ?, contact_email = ? where contact_id = ?;";
    contactSubDAO contactsubdao = new contactSubDAO();
    contactSub submission = new contactSub();
    contactSubServlet contactServlet = new contactSubServlet();
    HttpServletRequest request = mock(HttpServletRequest.class);
    HttpServletResponse response = mock(HttpServletResponse.class);


    @Test
    public void ServletTest() throws ServletException, IOException, SQLException {


        adminServlet aservlet = new adminServlet();
        aservlet.init();
        aservlet.doPost(request,response);

        contactServlet.init();

        contactsubdao.insertContactSub(submission);
        contactsubdao.selectSubmission(2);
        contactsubdao.selectAllSubmissions();
        contactsubdao.updateSubmission(submission);
        contactsubdao.deleteSubmission(20);

        when(request.getParameter("name")).thenReturn("MoJamba");
        when(request.getParameter("email")).thenReturn("mjamil@gmail.com");
        when(request.getParameter("message")).thenReturn("This is my messageoigigigigtiugigiugiugiugiugiugiugiubgiiuiuhgiuh!");
        when(request.getParameter("number")).thenReturn("1234567890");

    }



    @Test
    void contactSubClassTest(){
        contactSub submission = new contactSub();

        LocalDate curr = LocalDate.now();


        submission.setEmail("meofje@gmail.com");
        submission.setDate(Date.valueOf(curr));
        submission.setId(3);
        submission.setName("Mo Jamba");
        submission.setNumber("1234567890");
        submission.setMessage("This is my message! Ok! Got It");

        contactSub submissionID = new contactSub(1, submission.getName(), submission.getEmail(),
                submission.getMessage(), submission.getDate(), submission.getNumber());
        contactSub submissionID2 = new contactSub(submission.getName(), submission.getEmail(),
                submission.getMessage(), submission.getDate(), submission.getNumber());
        contactSub submissionID3 = new contactSub(11);

        System.out.println(submissionID.getMessage());


        System.out.println(submission.getEmail());
        System.out.println(submission.getDate());
        System.out.println(submission.getId());
        System.out.println(submission.getName());
        System.out.println(submission.getNumber());
        System.out.println(submission.getMessage());


    }

    @Test
    void contactSubServletTesting() throws ServletException, IOException, SQLException {
        contactSubServlet servlet = new contactSubServlet();
        HttpServletRequest req = mock(HttpServletRequest.class);
        HttpServletResponse res = mock(HttpServletResponse.class);


        when(request.getParameter("name")).thenReturn("MoJamba");
        when(request.getParameter("email")).thenReturn("mjamil@gmail.com");
        when(request.getParameter("message")).thenReturn("This is my messageoigigigigtiugigiugiugiugiugiugiugiubgiiuiuhgiuh!");
        when(request.getParameter("number")).thenReturn("1234567890");

    }


}
