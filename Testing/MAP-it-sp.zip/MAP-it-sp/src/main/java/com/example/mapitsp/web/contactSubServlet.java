package com.example.mapitsp.web;

import com.example.mapitsp.dao.contactSubDAO;
import com.example.mapitsp.model.contactSub;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/")
public class contactSubServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private contactSubDAO contactSubdao;


    public void init() {
        contactSubdao = new contactSubDAO();
    }

    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String action = request.getServletPath();

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertSubmission(request, response);
                    break;
                case "/delete":
                    deleteSub(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateSub(request, response);
                    break;
                default:
                    listSub(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    public void insertSubmission(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException{
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String message = request.getParameter("message");
            String number = request.getParameter("number");
            LocalDate currDate = LocalDate.now();
            Date current = Date.valueOf(currDate);
            contactSub submission = new contactSub(name, email, message, current, number);
            contactSubdao.insertContactSub(submission);
            response.sendRedirect("list");

    }


    public void listSub(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException, ServletException {
            List<contactSub> listSub = new ArrayList<>();
            listSub = contactSubdao.selectAllSubmissions();
            request.setAttribute("listSub", listSub);
            RequestDispatcher dispatcher = request.getRequestDispatcher("admin-view.jsp");
            dispatcher.forward(request,response);
    }

    public void showNewForm(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException, ServletException {
            RequestDispatcher dispatcher = request.getRequestDispatcher("sub-form.jsp");
            dispatcher.forward(request,response);
    }

    public void showEditForm(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException, ServletException {
            int id = Integer.parseInt(request.getParameter("id"));
            contactSub existingSub = contactSubdao.selectSubmission(id);
            RequestDispatcher dispatcher = request.getRequestDispatcher("sub-form.jsp");
            request.setAttribute("submission", existingSub);
            dispatcher.forward(request,response);

    }

    public void updateSub(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException {
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String message = request.getParameter("message");
            String number = request.getParameter("number");
            LocalDate currDate = LocalDate.now();
            Date current = Date.valueOf(currDate);
            contactSub submission = new contactSub(id, name, email, message, current, number);
            contactSubdao.updateSubmission(submission);
            response.sendRedirect("list");
    }

    public void deleteSub(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException {
            int id = Integer.parseInt(request.getParameter("id"));
            contactSubdao.deleteSubmission(id);
            response.sendRedirect("list");
    }

}
