package com.example.mapitsp.web;

import com.example.mapitsp.dao.contactSubDAO;
import com.example.mapitsp.model.contactSub;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/contact-submission")
public class contactSubServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private contactSubDAO contactSubdao;


    public void init() {
        contactSubdao = new contactSubDAO();
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //String action = request.getServletPath();
        //try catch with swtich cases
        try {
            insertSubmission(request,response);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void insertSubmission(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException{
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String message = request.getParameter("message");
            String number = request.getParameter("number");

            Long datetime = System.currentTimeMillis();
            Timestamp dateTime = new Timestamp(datetime);

            contactSub submission = new contactSub(name,email,message, dateTime, number);
            contactSubdao.insertContactSub(submission);
            response.sendRedirect("main/webapp/home.jsp");

    }
}
