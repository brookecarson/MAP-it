package com.example.mapitsp.model;

import java.sql.Timestamp;

public class contactSub {

    protected int id;
    protected String name;
    protected String email;
    protected String message;
    protected Timestamp date_time;
    protected String number;

    public contactSub(){

    }

    public contactSub(String name, String email, String message, Timestamp date_time, String number) {
        super();
        this.name = name;
        this.email = email;
        this.message = message;
        this.date_time = date_time;
        this.number = number;
    }

    public contactSub(int subID, String name, String email, String message, Timestamp date_time, String number) {
        super();
        this.id = subID;
        this.name = name;
        this.email = email;
        this.message = message;
        this.date_time = date_time;
        this.number = number;
    }

    public int getId() {return id;}

    public void setId(int id) {this.id = id;}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Timestamp getDate_time() {return date_time;}

    public void setDate_time(Timestamp date_time) {
        this.date_time = date_time;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
