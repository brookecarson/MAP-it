const mongoose = require('mongoose');

const contactSubSchema = new mongoose.Schema({
    name: String,
    email: String,
    number: String,
    message: String,
    date: {type: Date, default: Date.now },

});

const contactSubModel = mongoose.model('submission',contactSubSchema)

exports.readAll = async function(){
    let submissions = await contactSubModel.find();
    return submissions;
}

exports.read = async function (id) {
    let sub = await contactSubModel.findById(id);
    return sub;
}

exports.create = async function(submission){
    const sub = new contactSubModel(submission);
    await sub.save();
    return sub;
}

exports.del = async function(id){
    let mainSub = await contactSubModel.findByIdAndDelete(id);
    return mainSub;
}

exports.deleteAll = async function(){
    await contactSubModel.deleteMany();
}

exports.update = async function(submission){
    let prevSub = await contactSubModel.findByIdAndUpdate(submission._id, submission);
    return prevSub;
}

