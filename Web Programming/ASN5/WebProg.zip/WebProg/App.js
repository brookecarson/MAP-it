const express = require('express'); //import express
const morgan = require('morgan'); //import morgan for logging
const subController = require('./controller/ContactSubController');

const app = express(); //creates a new Express Application
app.use(morgan('dev')); //For better logging, we use morgan
app.use(express.urlencoded({extended:true}));
app.use(express.json());

app.use(express.static('public_html'));// Static server use the folder 'public_html'


app.get('/submission', subController.getAll);
app.get('/submission/:id', subController.get);
app.post('/submission', subController.postCreateUpdate);
app.get('/delsub/:id', subController.deleteOne);
app.post('/updatesub', subController.postCreateUpdate);

exports.app = app;