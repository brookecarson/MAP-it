const dao = require('../model/ContactSubDaoMongo');
const dbcon = require('../model/DbConnection');



beforeAll(function (){
    dbcon.connect('test');
});

afterAll(async function(){
    await dao.deleteAll()
    dbcon.disconnect();
});

beforeEach(async function(){
   await dao.deleteAll();
});


test('Test ReadAll Submissions',function(){
    let submissions = dao.readAll();
    expect(submissions).toBeDefined();
});

test('Test Read ', function(){
    let begin = dao.readAll();
    let firstSub = dao.read(begin._id);
    expect(begin._id).toEqual(firstSub._id);
});


test('Test Create Submission', function(){
    let newSubmission = {name:'Ray James', email: 'rj23@gmail.com',number:'8795462722',message:'Was hoping someone could help me out with signing up? Thanks',date:'03/22/2020'};
    let saved = dao.create(newSubmission);
    let foundIt = dao.read(saved._id);
    expect(foundIt._id).toEqual(saved._id);
});

test('Delete Submission', function(){

    let begin = dao.readAll();
    dao.deleteAll();
    let removed = dao.del(begin._id);
    expect(removed._id).toEqual(begin._id);

});
