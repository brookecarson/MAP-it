const express = require('express'); //import express
const morgan = require('morgan'); //import morgan for logging
const app = express(); //creates a new Express Application
app.use(morgan('dev')); //For better logging, we use morgan

let hostname = 'localhost';
let port = 4000;
app.use(express.static('public_html'));// Static server use the folder 'public_html'

const submissions = [
    {_id:1,name:'Mohammad Jamil', email: 'mjamil@gmail.com',number:'1234567890',message:'Admin Checkin',password:'mjamil1!',permission: 2},
    {_id:2,name:'Brooke Carson', email: 'bcarson@gmail.com',number:'4439391099',message:'Admin Checkin 2',password:'bcarson1!',permission: 2},
    {_id:3,name:'John Jones', email: 'jsquared@gmail.com',number:'1234784562',message:'This is my message, great website, Thanks!',password:'jboi001!',permission: 1},
    {_id:4,name:'Jeremy Jackson', email: 'jackboi@gmail.com',number:'9240515952',message:'I approves this!',password:'jeremy636',permission: 1},
    {_id:5,name:'Louis Len', email: 'lendakid@gmail.com',number:'6672315020',message:'Great job!',password:'lenlen09',permission: 1},
    {_id:6,name:'Kenzie Kantron', email: 'kdawg@hotmail.com',number:'6109323452',message:'This is a message, enjoy!',password:'doubleKHere',permission: 1},
    {_id:7,name:'Carson Campbell', email: 'campbellsoup@gmail.com',number:'8795462031',message:'I am named after canned soup',password:'soupy',permission: 1},
    {_id:8,name:'Matt Murdock', email: 'murdockm@gmail.com',number:'1234567432',message:'I am a superhero',password:'mMurdock124!',permission: 1},
    {_id:9,name:'Clark Kent', email: 'superboi@gmail.com',number:'1234567893',message:'I might be superman',password:'superduper1!',permission: 1},
    {_id:10,name:'Bruce Waynes', email: 'batman12@gmail.com',number:'9876541231',message:'I like bats',password:'batBoi',permission: 1}];

app.get('/submission',function(req,res,next){
    res.status(200); // Ok status
    res.send(submissions); // Sending the array
    res.end(); // Ends the response (optional)
});

app.get('/submission/:id',function(req,res,next){
    let id = parseInt(req.params.id);
    let submission = null;
    for(let i=0; i<submissions.length; i++)
        if(submissions[i]._id === id){ submission = submissions[i]; break;}
    if(submission!=null){ // if submission exists
        res.status(200).send(submission); // Status 200 = OK
    } else{
        res.status(404); // Status 404 = Not Found
        res.send({msg:'submission does not exist.'});
    }
    res.end(); // ends the response
});


const server=app.listen(port,hostname,function(){ // Listen to client requests in hostname:port
    console.log(`Server Running on ${hostname}:${port}...`);
});