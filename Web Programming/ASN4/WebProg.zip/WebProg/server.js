const express = require('express'); //import express
const morgan = require('morgan'); //import morgan for logging
const dao = require('./model/ContactSubDao');

let port = 4000;
let hostname = 'localhost';

const app = express(); //creates a new Express Application
app.use(morgan('dev')); //For better logging, we use morgan
app.use(express.urlencoded({extended:true}));
app.use(express.json());

app.use(express.static('public_html'));// Static server use the folder 'public_html'


app.get('/submission',function(req,res,next){
    res.status(200); // Ok status
    res.send(dao.readAll()); // Sending the array
    res.end(); // Ends the response (optional)
});

app.get('/submission/:id',function(req,res,next){

    let id = parseInt(req.params.id);
    let found = dao.read(id);

    if(found !== null){
        res.status(200);
        res.send(found);
    }

    else{
        res.status(404);
        res.send({msg: 'Submission Not Found.'});
    }

    res.end();
});

app.post('/submission',function(req,res){

    let newSub = {};
    newSub.name = req.body.txt_name;
    newSub.email = req.body.txt_email;
    newSub.number = req.body.txt_number;
    newSub.message = req.body.txt_message;
    newSub.date = req.body.txt_date;

    if(req.body.txt_id){
        dao.update(newSub);
    }
    else{
        dao.create(newSub);
    }
    res.redirect('admin_view.html');

});


app.get('/delsub/:id',function(req,res){
    let id = parseInt(req.params.id);
    dao.del(id);
    res.redirect('../admin_view.html');
});

app.post('/updatesub',function(req,res){

});


const server=app.listen(port,hostname,function(){ // Listen to client requests in hostname:port
    console.log(`Server Running on ${hostname}:${port}...`);
});