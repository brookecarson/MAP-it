const dao = require('../model/ContactSubDao');

exports.getAll = async function(req,res){
    res.status(200);
    res.send(await dao.readAll());
    res.end();
}

exports.get = function(req,res){

    let id = req.params.id;
    let foundIt = dao.read(id);

    if(foundIt !== null){
        res.status(200);
        res.send(foundIt);
    }
    else{
        res.status(404);
        res.send({msg: 'Submission not found.'});
    }
    res.end();
}

exports.postCreateUpdate = function(req,res){
    let newSub = {};

    newSub.name = req.body.txt_name;
    newSub.email = req.body.txt_email;
    newSub.number = req.body.txt_number;
    newSub.message = req.body.txt_message;
    newSub.date = req.body.txt_date;

    if(req.body.txt_id){
        dao.update(newSub);
    }
    else{
        dao.create(newSub);
    }
    res.redirect('admin_view.html');

}

exports.deleteOne = function(req,res){
    let id = req.params.id;
    dao.del(id);
    res.redirect('../admin_view.html');

}