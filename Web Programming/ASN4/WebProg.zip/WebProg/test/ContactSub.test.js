const dao = require('../model/ContactSubDao');

test('Test ReadAll Submissions',function(){
    let submissions = dao.readAll();
    expect(submissions.length).toBeGreaterThan(0);
});

test('Create Read Submission', function(){
    let newSubmission = {_id:33, name:'Ray James', email: 'rj23@gmail.com',number:'8795462722',message:'Was hoping someone could help me out with signing up? Thanks',date:'03/22/2020'};
    let beforeSize = dao.readAll().length;
    let saved = dao.create(newSubmission);
    let subs = dao.readAll();
    let reader = dao.read(33);
    expect(subs.length).toBe(beforeSize+1);
    expect(subs).toContain(saved);

    dao.update(newSubmission);

});

test('Delete Update Submission', function(){

    let newSubmission = {_id:44, name:'Ray James', email: 'rj23@gmail.com',number:'8795462722',message:'Was hoping someone could help me out with signing up? Thanks',date:'03/22/2020'};
    let beforeSize = dao.readAll().length;
    let saved = dao.create(newSubmission);
    let subs = dao.readAll();
    let deletedSub = dao.del(44);
    !expect(subs).toContain(newSubmission);

});
