exports.submissions = [

    {_id:1,name:'Mohammad Jamil', email: 'mjamil@gmail.com',number:'1234567890',message:'I love this website, thanks for this!',date:'07/02/2021'},
    {_id:2,name:'Brooke Carson', email: 'bcarson@gmail.com',number:'4439391099',message:'Could you please send me an email of upcoming events? Thanks',date:'07/09/2021'},
    {_id:3,name:'John Jones', email: 'jsquared@gmail.com',number:'1234784562',message:'This is my message, great website, Thanks!',date:'06/22/2021'},
    {_id:4,name:'Jeremy Jackson', email: 'jackboi@gmail.com',number:'9240515952',message:'I approves this!',date:'05/27/2021'},
    {_id:5,name:'Louis Len', email: 'lendakid@gmail.com',number:'6672315020',message:'Great job!',date:'01/22/2021'},
    {_id:6,name:'Kenzie Kantron', email: 'kdawg@hotmail.com',number:'6109323452',message:'This is a message, enjoy!',date:'04/12/2021'},
    {_id:7,name:'Carson Campbell', email: 'campbellsoup@gmail.com',number:'8795462031',message:'I am named after canned soup',date:'10/08/2021'},
    {_id:8,name:'Matt Murdock', email: 'murdockm@gmail.com',number:'1234567432',message:'I am a superhero',date:'02/11/2022'},
    {_id:9,name:'Clark Kent', email: 'superboi@gmail.com',number:'1234567893',message:'I might be superman',date:'07/19/2021'},
    {_id:10,name:'Bruce Waynes', email: 'batman12@gmail.com',number:'9876541231',message:'I like bats',date:'11/13/2021'}

];

exports.readAll = function(){
    return exports.submissions;
}

exports.read = function(id){
    let iterator = pos(id);
    if(iterator >= 0) return exports.submissions[iterator];
    else return null;
}

exports.create = function(submission){
    if(exports.submissions.length>0)
        submission._id = (exports.submissions[exports.submissions.length-1]._id)+1;
    else
        submission._id = 1;
    exports.submissions.push(submission);
    return submission;
}

exports.del = function(id){
    let iterator = pos(id);
    let deletedSubmission = null;
    if(iterator >= 0){
        deletedSubmission = exports.submissions[iterator];
        exports.submissions.splice(iterator,1);
    }
    return deletedSubmission;
}

exports.update = function(submission){
    let iterator = pos(submission.id);
    exports.submissions[iterator].name = submission.name;
    exports.submissions[iterator].email = submission.email;
    exports.submissions[iterator].message = submission.message;
    exports.submissions[iterator].number = submission.number;
    exports.submissions[iterator].date = submission.date;

    return submission;
}

function pos(id){
    for(let i = 0; i<exports.submissions.length; i++){
        if(exports.submissions[i]._id === id){
            return i;
        }
    }
    return -1;
}
